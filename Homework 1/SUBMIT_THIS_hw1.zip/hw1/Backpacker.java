package hw1;

/*
 * 
 * @Author Drake Ridgeway
 * 
 */
public class Backpacker {            //Backpacker Class
	
	public static final int SYMPATHY_FACTOR = 30;
	private Location backpackerLocation;
	private String currentJournal;
	private int currentFunds;                            //Instance Variables
	private int postcardsSent;
	private int totalTrainNights;
	
	/* @param
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public Backpacker(int initialFunds, Location initialLocation) {    //Takes currentFunds and backpackerLocation  
		                                                               //and assigns them to their respectable 		
		currentFunds = initialFunds;                                   //counterparts for the method
		backpackerLocation = initialLocation;
		currentJournal = initialLocation.getName() + "(start)";
	}
	
	/* @return
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public String getCurrentLocation() {       //gets the current location for the backpacker
		
		return backpackerLocation.getName();     //gets the name of the current location for the backpacker
	}
	
	/* @return
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public int getCurrentFunds() {            //gets current funds for the backpacker
				
		return currentFunds;                  //displays backpacker's current funds
	}
	
	/* @return
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public String getJournal() {              //gets the journal for the backpacker
		
		return currentJournal;              //displays the backpacker's journal
	}
	
	/* @return
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public boolean isSOL() {                  //Method to see if the backpacker is SOL
		
		return getCurrentFunds() < backpackerLocation.costToSendPostcard();         //if currentFunds is less than the cost to send a postcard, the backpacker is SOL
	}   
	
	/* @return
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public int getTotalNightsInTrainStation() {  //gets the total nights spent at the train station
		
		return totalTrainNights;                 //displays the total nights in the train station
	}
	
	/* @param
	 * @return
	 * @Author Drake Ridgeway
	 * 
	 */
	public void visit(Location c, int numNights) {    //Method that visits a certain location and goes through the name and price
		
		backpackerLocation = c;
		currentJournal += c.getName() + "(" + numNights + "),";                              //writing in the journal
		int totalStayCost = c.lodgingCost() * numNights;                                     //calculates the total cost to stay at said location
		int numNightsPurchased = Math.min(totalStayCost, currentFunds) / c.lodgingCost();    //takes the minimum of total cost and currentFunds, then divides it by the lodging cost to determine if the backpacker can stay
		totalTrainNights = numNights - numNightsPurchased;                                   //calculates the total nights at the train station
		currentFunds = currentFunds - (c.lodgingCost() * numNightsPurchased);                //calculates the currentFunds after staying a night
	}
	
	/* @param	 
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public void sendPostcardsHome(int howMany) {
		
		postcardsSent += Math.min(howMany, backpackerLocation.maxNumberOfPostcards(currentFunds));
		
	}
	
	/* 
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public void callHomeForMoney() {
		
		postcardsSent = 0;
		currentFunds += SYMPATHY_FACTOR;
	}

}
