package hw1;

/*
 * 
 * @Author Drake Ridgeway
 * 
 */
public class Location {         //Location class
	
	public static final double RELATIVE_COST_OF_POSTCARD = 0.05;   //the permanent cost of a postcard
	private String lodgeName;        
	private int costOfLodge;              //Instance Variables
	
	/*
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public Location(String givenName, int givenLodgingCost) {   //Name and cost of a certain lodge
	
		lodgeName = givenName;                    //assigns lodgeName to the givenName
		costOfLodge = givenLodgingCost;           //assigns costOfLodge to the givenLodgingCost
	}
    
	/*
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public String getName() {    //gets name of lodge
		
		return lodgeName;        //returns the name of the lodge
	}
    
	/*
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public int lodgingCost() {   //gets price of lodge
		
		return costOfLodge;      //returns the cost of the lodge
	}
	/*
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public int costToSendPostcard() {     //the cost to send a postcard home
		
		return (int) Math.round(RELATIVE_COST_OF_POSTCARD * costOfLodge);    //rounds the product of these two variables
	}
	/*
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public int maxLengthOfStay(int funds) {     //maximum length of stay in a lodge
		
		return (funds / costOfLodge);           //takes the funds and integer divides it by the cost of the lodge
	}
	/*
	 * 
	 * @Author Drake Ridgeway
	 * 
	 */
	public int maxNumberOfPostcards(int funds) {    //limit to postcards you can send
		
		return (funds / costToSendPostcard());    //takes the funds and integer divides it by the cost to send the postcard
	}
}

