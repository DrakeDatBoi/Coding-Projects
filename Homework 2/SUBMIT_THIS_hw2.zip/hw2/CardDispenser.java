package hw2;
/**
 * This class models inserting a card and setting the time inserted.
 * @author drake
 */
public class CardDispenser {

	private TimeClock c;         //instance variable for TimeClock
	
	 /**
	   * Constructs a clock, which the time is given in the test.
	   * @param givenClock
	   */
	public CardDispenser(TimeClock givenClock) {
		
		c = givenClock;
	}
	
	/**
	 * Constructs a new ParkingCard, and gets the time for the payment.
	 * Returns the ParkingCards's payment time.
	 * @return
	 */
	public ParkingCard takeCard(){
		
        ParkingCard pc = new ParkingCard(c.getTime());
        pc.setPaymentTime(0);
        return pc;
	}
	
}
