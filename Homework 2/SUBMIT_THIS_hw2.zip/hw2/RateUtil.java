package hw2;

/**
 * This class calculates the cost of the stay, having set values from the amount of time 
 * stayed.
 * @author drake
 *
 */
public class RateUtil {
		
	public static final int EXIT_TIME_LIMIT = 15;  //static final variable that cannot be surpassed
	
	
	private RateUtil() {
			
	}
	
	/**
	 * This method is the math behind calculating the total cost of a stay, using if statements, and
	 * adding it to the cost. Ultimately returning the cost.
	 * @param minutes
	 * @return
	 */
	public static double calculateCost(int minutes) {
		
		int min = 0;
		int days = (int) Math.floor(minutes / 1440);
		double cost = days * 13.0;
		min = minutes % 1440;
		
		if(min <= 30) {
			cost += 1.00;
		}
		if(min > 30 && min <= 60) {
			cost += 2.00;
		}
		if(min > 60 && min <= 120) {
			cost += 3.50;
		}
		if(min > 120 && min <= 180) {
			cost += 5.00;
		}
		if(min > 180 && min <= 240) {
			cost += 6.50;
		}
		if(min > 240 && min <= 300) {
			cost += 8.00;
		}
		if(min > 300 && min <= 360) {
			cost += 9.25;
		}
		if(min > 360 && min <= 420) {
			cost += 10.50;
		}
		if(min > 420 && min <= 480) {
			cost += 11.75;
		}
		if(min > 480) {
			cost += 13.00;
		}
		
		return cost;
	}
}
