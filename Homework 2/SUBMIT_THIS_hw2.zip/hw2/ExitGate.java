package hw2;
/**
 * This class models the exit gate of a parking garage, getting the time of leave
 * and incrementing the exit count.
 * @author drake
 *
 */
public class ExitGate {

	private int exitCount;          //instance variable that increment the exit count and construct a new time clock
	private TimeClock clock;
	
	/**
	 * A class that assigns givenClock with the newly constructed clock.
	 * @param givenClock
	 */
	public ExitGate(TimeClock givenClock) {
		
		clock = givenClock;	
	}
	
	/**
	 * This method will increment exitCount if the time is below EXIT_TIME_LIMIT and the payment time is above 0
	 * returns true or false.
	 * @param c
	 * @return
	 */
	public boolean insertCard(ParkingCard c) {
		
		if(clock.getTime() - c.getPaymentTime() <= RateUtil.EXIT_TIME_LIMIT && c.getPaymentTime() > 0){
			exitCount += 1;
			return true;
		}
		return false;
	}
	
	/**
	 * This method increments exitCount and returns it.
	 * @return
	 */
	public int getExitCount() {
		
		return exitCount;		
	}

	
}
