package hw2;

/**
 * This class represents a payment station that will calculate the cost of your stay
 * by making sure that a card is inserted and has set values on how much the stay
 * will be in a separate class.
 * @author drake
 *
 */
public class PayStation {

	private double paymentDue;
	private double totalPayment;
	private boolean progress = false;      //instance variables that have the payment that is due from the stay, total payment from all tickets
	private ParkingCard pc;                // progress shows that a card is inserted or not, and constructing a new parkingCard and TimeClock
	private TimeClock c;
	
	/**
	 * This class assigns a variable to the newly constructed TimeClock.
	 * @param givenClock
	 */
	public PayStation(TimeClock givenClock) {
		
		c = givenClock;
	}
	
	/**
	 * This method, when the card is inserted, will change from true to false
	 * showing that the card is inserted.
	 * @param t
	 */
	public void insertCard(ParkingCard t) {
		
		if(progress == false) {
			pc = t;
			progress = true;
		}
	}
	
	/**
	 * This method returns the current state of the card, true or false, meaning
	 * inserted or not inserted.
	 * @return
	 */
	public ParkingCard getCurrentCard() {
		
		return pc;
	}
	
	/**
	 * This method returns the progress of the card.
	 * @return
	 */
	public boolean inProgress() {
		
		return progress;
	}
	
	/**
	 * This method calculates the payment that is due from the stay as long as progress is true, returns the payment due.
	 * @return
	 */
	public double getPaymentDue() {
		
		if(progress == true) {
			paymentDue = RateUtil.calculateCost(c.getTime() - pc.getStartTime());
			if (pc.getPaymentTime() != 0) {
				paymentDue = paymentDue - RateUtil.calculateCost(pc.getPaymentTime() - pc.getStartTime());
			}
					
		}
		
		return paymentDue;
	}
	
	/**
	 * This method calculates the total payment from all tickets, as long as progress is true, it will calculate.
	 */
	public void makePayment() {
		
		if(progress == true) {
			pc.setPaymentTime(c.getTime());
			totalPayment += getPaymentDue();
		}
	}
	
	/**
	 * This method ejects the card, changing the current state of the card to false.
	 */
	public void ejectCard() {
		
		if(progress == true) {
			pc = null;
			progress = false;
		}
	}
	
	/**
	 * This method returns the total payment from all tickets.
	 * @return
	 */
	public double getTotalPayments() {
		
		return totalPayment;
	}
}
