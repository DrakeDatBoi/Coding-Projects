package hw4;

import api.IStatefulComponent;

public class Counter extends AbstractStatefulComponent implements IStatefulComponent {
	
	private int currentState;
	private int n;
	
	/**
	 * Constructs a new Counter
	 * @param n
	 */
	public Counter(int n) {
		super(0, n);
		
		this.currentState = 0;
		this.n = n;
		
		clear();
	}
	
	/**
	 * Updates the internal state
	 */
	public void tick() {
		if (inputsValid()) {
			invalidateOutputs();
			
			currentState++;
			String b = Integer.toBinaryString(currentState);
			
			char c = ' ';
			int num = 0;
			
			for (int i = 0; i < Math.min(b.length(), n); i++) {
				c = b.charAt(b.length() - i - 1);
				num = Character.getNumericValue(c);
				outputs()[i].set(num);
			}
		}
	}
}
