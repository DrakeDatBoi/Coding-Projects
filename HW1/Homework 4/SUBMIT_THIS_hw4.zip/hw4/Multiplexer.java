package hw4;

public class Multiplexer extends AbstractComponent {
	
	private int m;
	
	/**
	 * Constructs a new Multiplexer
	 * @param m
	 */
	public Multiplexer(int m) {
		super(((int) Math.pow(2,  m) + m), 1);
		
		this.m = m;
	}
	
	/**
	 * Propagates the solution
	 */
	public void propagate() {
		
		int c = m - 1;
		int output = 0;
		
		for (int i = (int) (Math.pow(2,  m) + m) - 1; i >= (int) (Math.pow(2,  m) + m) - m; i--) {
			output += inputs()[i].getValue() * Math.pow(2,  c);
			c--;
		}
		
		outputs()[0].set(inputs()[output].getValue());
	}

}
