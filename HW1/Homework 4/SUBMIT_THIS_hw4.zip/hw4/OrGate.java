package hw4;

public class OrGate extends AbstractComponent {
	
	/**
	 * Constructs a new OrGate object
	 */
	public OrGate() {
		super(2, 1);
	}
	
	/**
	 * Propagates the solution
	 */
	public void propagate() {
		
		int temp = 0;
		if (inputsValid()) {
			if (inputs()[0].getValue() == 1 || inputs()[1].getValue() == 1) {
				temp = 1;
			}
			
			outputs()[0].set(temp);
		}
	}
}
