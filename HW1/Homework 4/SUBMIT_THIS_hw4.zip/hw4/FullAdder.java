package hw4;

import api.IComponent;

public class FullAdder extends CompoundComponent {
	
	private IComponent halfAdderLeft;
	private IComponent halfAdderRight;
	private IComponent orGate;
	
	/**
	 * constructs a new FullAdder
	 */
	public FullAdder() {
		super(3, 2);
		
		halfAdderLeft = new HalfAdder();
		halfAdderRight = new HalfAdder();
		orGate = new OrGate();
		
		addComponent(halfAdderLeft);
        addComponent(halfAdderRight);
        addComponent(orGate);

        inputs()[0].connectTo(halfAdderLeft.inputs()[0]);
        inputs()[1].connectTo(halfAdderLeft.inputs()[1]);
        inputs()[2].connectTo(halfAdderRight.inputs()[0]);


        halfAdderLeft.outputs()[0].connectTo(halfAdderRight.inputs()[1]);
        halfAdderLeft.outputs()[1].connectTo(orGate.inputs()[0]);
        halfAdderRight.outputs()[1].connectTo(orGate.inputs()[1]);

        halfAdderRight.outputs()[0].connectTo(outputs()[0]);
        orGate.outputs()[0].connectTo(outputs()[1]);
	}

}
