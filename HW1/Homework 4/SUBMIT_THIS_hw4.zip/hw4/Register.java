package hw4;

import api.IStatefulComponent;

public class Register extends AbstractStatefulComponent implements IStatefulComponent {
	
	/**
	 * Constructs a new Register
	 * @param n
	 */
	public Register(int n) {
		super(n, n);
		clear();
	}
	
	/**
	 * Updates the internal state
	 */
	public void tick() {
		
		int[] currentState = new int[inputs().length];
		if (inputsValid()) {
			for (int i = 0; i < inputs().length; i++) {
				currentState[i] = inputs()[1].getValue();
			}
			
			for (int j = 0; j < outputs().length; j++) {
				outputs()[j].set(currentState[j]);
			}
		}
	}
}
