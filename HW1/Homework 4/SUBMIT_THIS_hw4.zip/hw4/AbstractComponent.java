package hw4;

import api.Pin;
import api.IComponent;

public abstract class AbstractComponent implements IComponent {
	
	private Pin[] inputs;
	private Pin[] outputs;
	private boolean isEnabled;
	
	/**
	 * Creates a new AbstractComponent
	 * @param input
	 * @param output
	 */
	public AbstractComponent(int input, int output) {
		
		inputs = new Pin[input];
		outputs = new Pin[output];
		isEnabled = false;
		
		for (int i = 0; i < inputs.length; i++) {
			inputs[i] = new Pin(this);
		}
		
		for (int i = 0; i < outputs.length; i++) {
			outputs[i] = new Pin(this);
		}
	}
	
	/**
	 * Returns array of Pin's inputs
	 * @return inputs
	 */
	public Pin[] inputs() {
		return inputs;
	}
	
	/**
	 * Returns array of Pin's outputs
	 * @return outputs
	 */
	public Pin[] outputs() {
		return outputs;
	}
	
	/**
	 * Returns if the inputs are valid
	 * @return true if all points are valid, false otherwise
	 */
	public boolean inputsValid() {
		for (Pin p : inputs) {
			if (!p.isValid()) {
				return false;
			}
		}
		
		return true;		
	}
	
	/**
	 * Returns if the outputs are valid
	 * @return true if all outputs are valid, false otherwise
	 */
	public boolean outputsValid() {
		for (Pin p : outputs) {
			if (!p.isValid()) {
				return false;
			}
		}
		
		return true;		
	}
	
	/**
	 * Changes the state of all inputs to invalid
	 */
	public void invalidateInputs() {
		for (Pin p : inputs) {
			if (p.isValid()) {
				p.invalidate();
			}
		}
	}
	
	/**
	 * Changes the state of all outputs to invalid
	 */
	public void invalidateOutputs() {
		for (Pin p : outputs) {
			if (p.isValid()) {
				p.invalidate();
			}
		}
	}	
}
	
	

	
		

	

