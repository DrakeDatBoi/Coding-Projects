package hw4;

import api.IComponent;
import java.util.ArrayList;

public class CompoundComponent extends AbstractComponent {
	
	private ArrayList<IComponent> components;
	
	/**
	 * Constructs a new CompoundComponent
	 * @param input
	 * @param output
	 */
	public CompoundComponent(int input, int output) {
		super(input, output);
		components = new ArrayList<>();
	}
	
	/**
	 * Adds a component to the list of components
	 * @param c
	 */
	public void addComponent(IComponent c) {
		components.add(c);
	}
	
	/**
	 * Returns a list of components
	 * @return the list of compound components
	 */
	public ArrayList<IComponent> getComponents(){
		return components;
	}
	
	/**
	 * Propagates the solution through component
	 */
	public void propagate() {
		for (IComponent c : components) {
			if (c.inputsValid()) {
				c.propagate();
			}
		}
	}

}
