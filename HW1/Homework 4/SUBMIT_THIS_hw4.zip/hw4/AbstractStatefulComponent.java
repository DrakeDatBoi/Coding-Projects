package hw4;

import api.Pin;
import api.IComponent;

public abstract class AbstractStatefulComponent implements IComponent {
	
	private Pin[] inputs;
	private Pin[] outputs;
	private boolean isEnabled;
	
	/**
	 * Creates new AbtractComponent
	 * @param input
	 * @param output
	 */
	public AbstractStatefulComponent(int input, int output) {
		
		inputs = new Pin[input];
		outputs = new Pin[output];
		isEnabled = false;
		
		for (int i = 0; i < inputs.length; i++) {
			inputs[i] = new Pin(this);
		}
		
		for (int i = 0; i < outputs.length; i++) {
			outputs[i] = new Pin(this);
		}
	}
	
	/**
	 * Clears the internal state
	 */
	public void clear() {
		for (int i = 0; i < outputs().length; i++) {
			outputs()[i].set(0);
		}
	}
	
	/**
	 * Returns whether all outputs are valid
	 */
	public void invalidateOutputs() {
		for (int i = 0; i < outputs().length; i++) {
			outputs()[i].set(0);
		}
	}
	
	/**
	 * propagates inputs to outputs
	 */
	public void propogate() {
		
	}
	
	/**
	 * Enables updates to outputs
	 * @param state
	 */
	public void setEnabled(boolean state) {
		isEnabled = state;
	}

}
