package hw4;

import api.IComponent;

public class MultiComponent extends CompoundComponent implements IComponent {

	/**
	 * Constructs a new MultiComponent
	 * @param components
	 */
	public MultiComponent(IComponent[] components) {
		
		super(components[0].inputs().length * components.length, components.length);
		
		for (int i = 0; i < components.length; i++) {
			for (int j = 0; j < components[i].inputs().length; j++) {
				components[i].inputs()[j].invalidate();
			}
			for (int j = 0; j < components[i].outputs().length; j++) {
				components[i].outputs()[j].invalidate();
			}
		}
		
		int n = 0;
		int m = 0;
		
		for (IComponent c : components) {
			addComponent(c);
			
			for (int i = 0; i < c.inputs().length; i++) {
				inputs()[n].connectTo(c.inputs()[i]);
				n++;
			}
			
			for (int j = 0; j < c.outputs().length; j++) {
				c.outputs()[j].connectTo(outputs()[m]);
				m++;
			}
		}
	}
	
	/**
	 * Propagates the solution
	 */
	public void propagate() {
		for (IComponent c : getComponents()) {
			c.propagate();
		}
	}
}
