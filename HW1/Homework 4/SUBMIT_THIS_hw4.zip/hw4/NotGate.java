package hw4;

public class NotGate extends AbstractComponent {
	
	/**
	 * Constructs a new NotGate object
	 */
	public NotGate() {
		super(1, 1);
	}
	
	/**
	 * Propagates the solution
	 */
	public void propagate() {
		
		int temp = 0;
		if (inputsValid()) {
			if (inputs()[0].getValue() == 0) {
				temp = 1;
			}
			
			outputs()[0].set(temp);
		}
	}
}
