package hw4;

import api.IComponent;
import api.IStatefulComponent;
import api.Util;

public class UltimateHW4Test {
	
 public static void main(String[] args) {
	 
  IComponent o = new OrGate();
  IComponent a = new AndGate();
  IComponent n = new NotGate();
  IComponent h = new HalfAdder();
  IComponent f = new FullAdder();
  IComponent m = new Multiplexer(3);
  IComponent o1 = new OrGate();
  IComponent o2 = new OrGate(); 
  IComponent o3 = new OrGate();  
  IComponent o4 = new OrGate();
  IComponent[] compList = { o1, o2, o3, o4 };
  
  MultiComponent multi = new MultiComponent(compList);
  
  IStatefulComponent r = new Register(4);
  IStatefulComponent c = new Counter(3);
  
  CompoundComponent tester = new CompoundComponent(2,1);
  
  IComponent[] allComponentTest =  {o,a,n,h,f,m,multi,r,c,tester};
  
  System.out.println("Testing initial invalidity of inputs. Expecting all false, except counter, which has no inputs");
  for(IComponent all : allComponentTest) {
   System.out.println(all.inputsValid());
  }
  
  Register reg = new Register(3);
  Util.setInputs(reg, "011");
  reg.setEnabled(true);
  reg.tick(); 
  System.out.println(Util.toString(reg.outputs())); // 011 
  reg.setEnabled(false);
  Util.setInputs(reg, "100");
  reg.tick();
  System.out.println(Util.toString(reg.outputs())); // still 011 
  reg.setEnabled(true);
  reg.tick();
  System.out.println(Util.toString(reg.outputs())); // 100 
  reg.clear(); 
  System.out.println(Util.toString(reg.outputs())); // 000
  
  Util.setInputs(o1, "00");
  Util.setInputs(o2, "01");
  Util.setInputs(o3, "10");
  Util.setInputs(o4, "11"); 
  
  System.out.println("Testing OR Gate. expecting - 0 1 1 1");
  System.out.println(Util.toString(o.outputs()));
  Util.setInputs(o, "00");
  o.propagate();
  System.out.println(Util.toString(o.outputs()));
  Util.setInputs(o, "01");
  o.propagate();
  System.out.println(Util.toString(o.outputs()));
  Util.setInputs(o, "10");
  o.propagate();
  System.out.println(Util.toString(o.outputs()));
  Util.setInputs(o, "11");
  o.propagate();
  System.out.println(Util.toString(o.outputs()));
  System.out.println("\n\n");
  
  System.out.println("Testing AND Gate. expecting - 0 0 0 1");
  System.out.println(Util.toString(a.outputs()));
  Util.setInputs(a, "00");
  a.propagate();
  System.out.println(Util.toString(a.outputs()));
  Util.setInputs(a, "01");
  a.propagate();
  System.out.println(Util.toString(a.outputs()));
  Util.setInputs(a, "10");
  a.propagate();
  System.out.println(Util.toString(a.outputs()));
  Util.setInputs(a, "11");
  a.propagate();
  System.out.println(Util.toString(a.outputs()));
  System.out.println("\n\n");
  
  System.out.println("Testing NOT Gate. expecting - 1 0");
  System.out.println(Util.toString(n.outputs()));
  Util.setInputs(n, "0");
  n.propagate();
  System.out.println(Util.toString(n.outputs()));
  Util.setInputs(n, "1");
  n.propagate();
  System.out.println(Util.toString(n.outputs()));
  System.out.println("\n\n");

  System.out.println("Testing Half Adder. expecting -- 00 01 01 10");
  System.out.println(Util.toString(h.outputs()));
  Util.setInputs(h, "00");
  h.propagate();
  System.out.println(Util.toString(h.outputs()));
  Util.setInputs(h, "01");
  h.propagate();
  System.out.println(Util.toString(h.outputs()));
  Util.setInputs(h, "10");
  h.propagate();
  System.out.println(Util.toString(h.outputs()));
  Util.setInputs(h, "11");
  h.propagate();
  System.out.println(Util.toString(h.outputs()));
  System.out.println("\n\n");

  System.out.println("Testing Full Adder. expecting -- 00 01 01 01 10 10 10 11");
  System.out.println(Util.toString(f.outputs()));
  Util.setInputs(f, "000");
  f.propagate();
  System.out.println(Util.toString(f.outputs()));
  Util.setInputs(f, "001");
  f.propagate();
  System.out.println(Util.toString(f.outputs()));
  Util.setInputs(f, "010");
  f.propagate();
  System.out.println(Util.toString(f.outputs()));
  Util.setInputs(f, "100");
  f.propagate();
  System.out.println(Util.toString(f.outputs()));
  Util.setInputs(f, "011");
  f.propagate();
  System.out.println(Util.toString(f.outputs()));
  Util.setInputs(f, "101");
  f.propagate();
  System.out.println(Util.toString(f.outputs()));
  Util.setInputs(f, "110");
  f.propagate();
  System.out.println(Util.toString(f.outputs()));
  Util.setInputs(f, "111");
  f.propagate();
  System.out.println(Util.toString(f.outputs()));
  System.out.println("\n\n");

  System.out.println("Testing Register. Expecting 0000 0000 0101, 0101, 0001, 0001, 0000, 0001, 0000, 0000");
  System.out.println(Util.toString(r.outputs()));
  Util.setInputs(r,"0001");
  r.tick();
  r.propagate();
  System.out.println(Util.toString(r.outputs()));
   
  r.setEnabled(true);
  Util.setInputs(r, "0101");
  r.tick();
  r.propagate();
  System.out.println(Util.toString(r.outputs()));
  
  r.setEnabled(false);
  Util.setInputs(r, "0001");
  r.tick();
  r.propagate();
  System.out.println(Util.toString(r.outputs()));
  
  r.setEnabled(true);
  Util.setInputs(r, "0001");
  r.tick();
  r.propagate();
  System.out.println(Util.toString(r.outputs()));
  
  r.clear();
  System.out.println(Util.toString(r.outputs()));
  r.propagate();
  System.out.println(Util.toString(r.outputs()));
  
  Util.setInputs(r, "0001");
  r.tick();
  r.propagate();
  r.setEnabled(false);
  r.clear();
  System.out.println(Util.toString(r.outputs()));

  r.propagate();
  System.out.println(Util.toString(r.outputs()));
  Util.setInputs(r,"1111");
  r.tick();
  System.out.println(Util.toString(r.outputs()));
  System.out.println("\n\n");

  System.out.println("Testing Counter. Expecting 000, 001, 010, 011, 100, 101, 110, 111, 000, 001, 010");
  System.out.println(Util.toString(c.outputs()));
  for (int i = 0; i < 10; i++) {
   c.tick();
   c.propagate();
   System.out.println(Util.toString(c.outputs()));
  }

  System.out.println("Testing Multiplexer. Expecting -,1,1,1,1...");
  System.out.println(Util.toString(m.outputs()));
  Util.setInputs(m, "11001000000");
  m.propagate();
  System.out.println(m.outputs()[0].getValue());
  Util.setInputs(m, "10100100000");
  m.propagate();
  System.out.println(m.outputs()[0].getValue());
  Util.setInputs(m, "00000000001");
  m.propagate();
  System.out.println(m.outputs()[0].getValue());
  Util.setInputs(m, "11110000000");
  m.propagate();
  System.out.println(m.outputs()[0].getValue());
  Util.setInputs(m, "01100001000");
  m.propagate();
  System.out.println(m.outputs()[0].getValue());
  System.out.println("\n\n");

  System.out.println("Testing MultiComponent. Expecting ----,1,1,1,0");
  System.out.println(Util.toString(multi.outputs()));
  multi.propagate();
  System.out.println(Util.toString(multi.outputs()));
   
  System.out.println("Testing Compound Component. Expecting -, 0, 1, 1, 0");
  System.out.println(Util.toString(tester.outputs()));
  OrGate xOrGate = new OrGate();
  NotGate xNotGate = new NotGate();
  AndGate xAndGate = new AndGate();
  AndGate xnAndGate= new AndGate();
  
  tester.addComponent(xOrGate);
  tester.addComponent(xNotGate);
  tester.addComponent(xAndGate);
  tester.addComponent(xnAndGate);
  
  tester.inputs()[0].connectTo(xnAndGate.inputs()[0]);
  tester.inputs()[1].connectTo(xnAndGate.inputs()[1]);
  tester.inputs()[0].connectTo(xOrGate.inputs()[0]);
  tester.inputs()[1].connectTo(xOrGate.inputs()[1]);
  
  xOrGate.outputs()[0].connectTo(xAndGate.inputs()[0]);
  xnAndGate.outputs()[0].connectTo(xNotGate.inputs()[0]);
  
  xNotGate.outputs()[0].connectTo(xAndGate.inputs()[1]);
  xAndGate.outputs()[0].connectTo(tester.outputs()[0]);
  
  Util.setInputs(tester,"00");
  tester.propagate();
  System.out.println(Util.toString(tester.outputs()));
  
  Util.setInputs(tester,"01");
  tester.propagate();
  System.out.println(Util.toString(tester.outputs()));
  
  Util.setInputs(tester,"10");
  tester.propagate();
  System.out.println(Util.toString(tester.outputs()));
  
  Util.setInputs(tester,"11");
  tester.propagate();
  System.out.println(Util.toString(tester.outputs()));
  
  
 }
}
